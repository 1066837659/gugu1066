package com.wj.jd.bean

/**
 * author wangjing
 * Date 2021/10/11
 * Description
 */
class VersionBean {
    var isUpdate: String? = null
    var content_url: String? = null
    var release: String? = null
    var content: String? = null
    var widgetTip = ""
}