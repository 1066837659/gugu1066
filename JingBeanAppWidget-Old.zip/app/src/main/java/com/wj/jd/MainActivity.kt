package com.wj.jd

import android.content.BroadcastReceiver
import android.content.Context
import kotlinx.android.synthetic.main.activity_main.*
import android.content.Intent
import android.content.IntentFilter
import android.net.Uri
import android.text.TextUtils
import android.util.Log
import android.view.View
import android.widget.Toast
import com.wj.jd.util.CacheUtil
import com.wj.jd.widget.WidgetUpdateDataUtil
import com.wj.jd.widget.WidgetUpdateDataUtil1
import com.wj.jd.widget.WidgetUpdateDataUtil2

class MainActivity : BaseActivity() {
    private lateinit var notificationUpdateReceiver: NotificationUpdateReceiver
    private lateinit var notificationUpdateReceiver1: NotificationUpdateReceiver1
    private lateinit var notificationUpdateReceiver2: NotificationUpdateReceiver2

    override fun setLayoutId(): Int {
        return R.layout.activity_main
    }

    override fun initView() {
        setTitle("京豆")
        back?.visibility = View.GONE
        var qq = CacheUtil.getString("QQ").toString();
        if(qq!=null&&qq.length>5){
            inputQQ.setText(qq);
        }
        if(Constants.qqGroupKey==""){
            addQQGroup.visibility=View.GONE;
        }
        lbl_msg.setText(Constants.message)
    }

    override fun initData() {
        initNotification()
        startUpdateService()
    }

    private fun startUpdateService() {
        /*
        * app进入重新启动更新数据后台服务
        * */
        if ("1" != CacheUtil.getString("startUpdateService")) {
            WidgetUpdateDataUtil.updateWidget("ck")
            WidgetUpdateDataUtil1.updateWidget("ck1")
            WidgetUpdateDataUtil1.updateWidget("ck2")
        }
    }

    private fun initNotification() {
        val intentFilter = IntentFilter()
        intentFilter.addAction("com.scott.sayhi")
        notificationUpdateReceiver = NotificationUpdateReceiver()
        registerReceiver(notificationUpdateReceiver, intentFilter)

        val intentFilter1 = IntentFilter()
        intentFilter1.addAction("com.scott.sayhi1")
        notificationUpdateReceiver1 = NotificationUpdateReceiver1()
        registerReceiver(notificationUpdateReceiver1, intentFilter1)

        val intentFilter2 = IntentFilter()
        intentFilter2.addAction("com.scott.sayhi2")
        notificationUpdateReceiver2 = NotificationUpdateReceiver2()
        registerReceiver(notificationUpdateReceiver2, intentFilter2)
    }




    override fun setEvent() {

        setting.setOnClickListener {
            val intent = Intent(this, SettingActivity::class.java)
            startActivity(intent)
        }

        muchCK.setOnClickListener {
            val intent = Intent(this, MuchCkActivity::class.java)
            startActivity(intent)
        }

        loginJd.setOnClickListener {
            if(inputQQ.text!=null&&inputQQ.text.toString().length>5){
                CacheUtil.putString("QQ",inputQQ.text.toString())
            }else{
                Toast.makeText(this, "未设置QQ或微信号\n请获取CK后复制发送给机器人", Toast.LENGTH_SHORT).show()
            }
            val intent = Intent(this, MyWebActivity::class.java)
            startActivity(intent)
        }

        updateCK.setOnClickListener {
            if (TextUtils.isEmpty(inputCK.text.toString())) {
                Toast.makeText(this, "CK为空，添加失败", Toast.LENGTH_SHORT).show()
            } else {
                CacheUtil.putString("ck", inputCK.text.toString())
                Toast.makeText(this, "CK添加成功", Toast.LENGTH_SHORT).show()
                inputCK.setText("")
                WidgetUpdateDataUtil.updateWidget("ck")
            }
        }

        addQQGroup.setOnClickListener {
            joinQQGroup(Constants.qqGroupKey)
        }
    }

    /****************
     *
     * 发起添加群流程。群号：豆豆交流群。(908891563) 的 key 为： n5xKKCpsHU-7IfmhYguyVmYXGo8t2pGy
     * 调用 joinQQGroup(n5xKKCpsHU-7IfmhYguyVmYXGo8t2pGy) 即可发起手Q客户端申请加群 豆豆交流群。(908891563)
     *
     * @param key 由官网生成的key
     * @return 返回true表示呼起手Q成功，返回false表示呼起失败
     */
    fun joinQQGroup(key: String): Boolean {
        val intent = Intent()
        intent.data = Uri.parse("mqqopensdkapi://bizAgent/qm/qr?url=http%3A%2F%2Fqm.qq.com%2Fcgi-bin%2Fqm%2Fqr%3Ffrom%3Dapp%26p%3Dandroid%26jump_from%3Dwebapi%26k%3D$key")
        // 此Flag可根据具体产品需要自定义，如设置，则在加群界面按返回，返回手Q主界面，不设置，按返回会返回到呼起产品界面    //intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            startActivity(intent)
            true
        } catch (e: java.lang.Exception) {
            // 未安装手Q或安装的版本不支持
            false
        }
    }

    inner class NotificationUpdateReceiver : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            Log.i("====", "NotificationUpdateReceiver")
            WidgetUpdateDataUtil.updateWidget("ck")
        }
    }

    inner class NotificationUpdateReceiver1 : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            Log.i("====", "NotificationUpdateReceiver1")
            WidgetUpdateDataUtil1.updateWidget("ck1")
        }
    }

    inner class NotificationUpdateReceiver2 : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            Log.i("====", "NotificationUpdateReceiver1")
            WidgetUpdateDataUtil2.updateWidget("ck2")
        }
    }
}