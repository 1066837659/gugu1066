package com.wj.jd

/**
 * author wangjing
 * Date 2021/10/11
 * Description
 */
object Constants {

    var isDebug = false

    // 量子地址  http://192.168.88.2:5088
    var quantumUrl =""

    //量子appkey
    var appKey = "1"

    //qq 群安卓推广 key 通过该网页获取 (https://qun.qq.com/join.html)
    var qqGroupKey ="rYHkJDToErvtLx7oxmX_bHXi5YBW1NWV"

    var message="使用说明\n设置QQ或者微信号后点击“登录获取CK”按钮获取CK\n复制后填入CK输入框。然后点击【更新CK状态】按钮，提示更新成功则CK已经缓存成功\n返回到桌面>编辑桌面>添加小工具（小组件），找到【京豆】添加到桌面即可 \n桌面小组件数据不更新怎么办？\n由于有些手机后台限制了app活动，此时要在任务管理器锁定app保持不被杀死，可在应用授权管理开启应用后台活动。"
}