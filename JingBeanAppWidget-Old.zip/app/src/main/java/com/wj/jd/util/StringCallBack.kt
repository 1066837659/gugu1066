package com.wj.jd.util

/**
 * author wangjing
 * Date 2021/6/10
 * Description
 */
interface StringCallBack {
    fun onSuccess(result: String)
    fun onFail()
}